import {Component} from "react";

class ChildComponent extends Component{
  state = {
   power : 1
  }

  increasePower = () => {
    this.setState({power : this.state.power+1})
  }
  render(){
    return <div>
        <h5>{this.state.power}</h5>
        <button onClick = {this.increasePower}>Increase Power with Arrow  Function</button>
      </div> 
  }
}

export default ChildComponent;